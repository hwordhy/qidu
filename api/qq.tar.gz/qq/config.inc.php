<?php

$apiOrder = 1;
$apiName = "qq";
$apiTitle = "QQ";
$apiConfigs[$apiName] = array();
$apiConfigs[$apiName]["appid"] = "101784534";
$apiConfigs[$apiName]["appkey"] = "ca2f52ffb6ef3c45a3fa469a768b6ee0";
$apiConfigs[$apiName]["callback"] = "http://www.xiaolianyuedu.com/api/qq/loginback.php";
$apiConfigs[$apiName]["ismobile"] = 0;
$apiConfigs[$apiName]["scope"] = "get_user_info,add_share,list_album,add_album,upload_pic,add_topic,add_one_blog,add_weibo";
$apiConfigs[$apiName]["binduser"] = 1;

?>
